import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import { FlowNavigationFinishEvent } from 'lightning/flowSupport';
import Name from '@salesforce/schema/ResidentialLoanApplication.Name';
import Status from '@salesforce/schema/ResidentialLoanApplication.Status';
import axisltd_Sub_Stage__c from '@salesforce/schema/ResidentialLoanApplication.axisltd_Sub_Stage__c';
import getContentDocuments from '@salesforce/apex/AxisGeneratedDocumentPreviewController.getContentDocuments';
import generateCAMReport from '@salesforce/apex/AxisCAMIPInvoke.generateCAMReport';

import getResponseText from '@salesforce/apex/AxisCAMIPInvoke.getResponseText';
import getResponseNew from '@salesforce/apex/AxisCAMIPInvoke.getResponseNew';

import isInCommunity from '@salesforce/apex/AxisGeneratedDocumentPreviewController.isInCommunity';



export default class AxisCamPreviewPage extends LightningElement {
    @api recordId;
    showSpinner = true;
    contentDocumentData;
    ExistingdocumentId;
    variant = 'brand';
    fileType = 'PDF';
    isCommunity = false;
    isCamReportExisting;
    loanApplicationName;
    jobId;
    reportName;
    CreatedDate;
    isgenerating = false;
    newdocumentId;
    versionId;
    newVersionId;
    canGenerateFile = false;
    opefilepreview = false;

    @wire(isInCommunity) wiredCommunity({ error, data }) {
        if (data) {
            this.isCommunity = data;
        } else if (error) {
        }
    }

    @wire(getRecord, { recordId: '$recordId', fields: [Name, Status, axisltd_Sub_Stage__c] })
    wiredRecord({ error, data }) {
        if (data) {
            this.loanApplicationName = data.fields.Name.value;
            if (data.fields.Status.value == 'Credit Decision' && data.fields.axisltd_Sub_Stage__c.value == 'In-Review') {
                this.canGenerateFile = true;
            }
            else {
                this.canGenerateFile = false;
            }
            this.fetchData();
        } else if (error) {
            console.error(error);
        }
    }


    fetchData() {
        getContentDocuments({ 'recordId': this.recordId, fileTitle: 'CAM' })
            .then(result => {
                this.contentDocumentData = result;
                this.typePDF = 'CAM';
                if (this.contentDocumentData.length > 0) {
                    this.reportName = result[0].docTitle;
                    this.CreatedDate = result[0].createdDate;
                    this.versionId = result[0].docVersionId;
                    this.ExistingdocumentId = result[0].contentDocumentId;
                    /*
                    if (this.isCommunity) {

                        this.versionId = result[0].docVersionId;
                        this.ExistingdocumentId = result[0].contentDocumentId;
                    }
                    else {

                        
                        this.ExistingdocumentId = result[0].contentDocumentId;

                    } */

                    this.isCamReportExisting = true;
                    this.showSpinner = false;
                }
                else {
                    this.isCamReportExisting = false;
                    if (this.canGenerateFile) {
                        this.generateReport(this.recordId);
                    }
                    else {
                        this.showSpinner = false;
                    }
                }
            })
            .catch(error => {
                this.showSpinner = false;
            });
    }

    generateReport(recordIdVal) {
        this.isCamReportExisting = false;
        this.isgenerating = true;

        generateCAMReport({ 'recordId': recordIdVal, 'loanApplicantionName': this.loanApplicationName , 'typePDF': this.typePDF})
            .then(result => {
                this.jobId = result;
                if (this.jobId) {
                    setTimeout(() => {
                        this.fetchContentDocument(this.jobId, recordIdVal);
                    }, 5000);

                }
                else {
                    console.error('Job Id Not Returned');
                    this.isgenerating = false;
                }
            })
            .catch(error => {
                console.error(error);
                this.showSpinner = false;
                this.isgenerating = false;
            });
    }
    fetchContentDocument(jobId, recordIdVal) {
        getResponseText({ 'recordId': recordIdVal, 'jobId': jobId, 'oldDocId': this.ExistingdocumentId })
            .then(result => {
                if (result) {
                    this.isCommunity = result.isCommunity;
                    this.newVersionId = result.docVersionId;
                    if (this.isCommunity) {
                        this.newVersionId = result.docVersionId;
                    }
                    else {
                        this.newdocumentId = result.contentDocumentId;
                        this.handleUploadFinished();

                    }
                }

            })
            .catch(error => {
                console.error(error);
                this.showSpinner = false;
                this.isgenerating = false;
            });
    }
    generateNew() {
        this.showSpinner = true;
        this.generateReport(this.recordId);
    }
    handleCloseFlow(event) {
        const navigateNextEvent = new FlowNavigationFinishEvent();
        this.dispatchEvent(navigateNextEvent);
    }
    handleUploadFinished() {
        //this.dispatchEvent(new RefreshEvent());
        getResponseNew({ 'newCont': this.newdocumentId })
            .then(result => {
                if (result) {
                    console.log('New Doc Came' + result);
                    this.newdocumentId = result.Id
                }
                this.showSpinner = false;
                this.isgenerating = false;
                this.newFileGenerated = true;
            })
            .catch(error => {
                console.error(error);
                this.showSpinner = false;
                this.isgenerating = false;
            });
    }

}